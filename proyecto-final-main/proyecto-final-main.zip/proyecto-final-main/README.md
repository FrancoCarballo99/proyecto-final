# proyecto-final
Proyecto final "Plataforma de series y películas"

- Pantalla de registro e inicio de sesión.

- Pantalla principal:
+ Películas.
+ Series.
+ Banner que cada 10 segundos muestre recomendaciones del día.
+ Categorías.
+ Top 10.
+ "Mi lista".
+ Administrador y usuarios.
+ Usuario específico para niños/as.
+ Barra de búsqueda.
+ Base de datos.
